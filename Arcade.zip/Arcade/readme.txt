Welcome to Ava and Lucas' arcade, we hope you enjoy!

In order to play this game you must download Python from the following website: https://www.python.org/downloads/

Make sure it is python 2.7, not 3.6. The game will not run if you have 3.6!

How to play the games:

1) Open the file titled ArcadeMethods.py with python 2.7

2) Go to the “run” menu on the toolbar, and click “run module”.

3) Don’t lose!

Additional directions are in the game.

Question or feedback? Contact us at:           
asinai20@germantownfriends.org
lkiewek21@germantownfriends.org